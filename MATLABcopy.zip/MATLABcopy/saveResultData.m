fileID=fopen('rawDataG.txt','w');
fprintf(fileID,'%s\n','G');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,G);
fclose(fileID);

fileID=fopen('rawDataD.txt','w');
fprintf(fileID,'%s\n','D');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,D);
fclose(fileID);

fileID=fopen('rawDataE.txt','w');
fprintf(fileID,'%s\n','E');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,E);
fclose(fileID);

fileID=fopen('rawDataV.txt','w');
fprintf(fileID,'%s\n','V');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,V);
fclose(fileID);

fileID=fopen('rawDataA.txt','w');
fprintf(fileID,'%s\n','A');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,A);
fclose(fileID);

fileID=fopen('rawDataR.txt','w');
fprintf(fileID,'%s\n','R');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,R);
fclose(fileID);

fileID=fopen('rawDataS.txt','w');
fprintf(fileID,'%s\n','S');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,S);
fclose(fileID);

fileID=fopen('rawDataK.txt','w');
fprintf(fileID,'%s\n','K');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,K);
fclose(fileID);

fileID=fopen('rawDataN.txt','w');
fprintf(fileID,'%s\n','N');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,N);
fclose(fileID);

fileID=fopen('rawDataI.txt','w');
fprintf(fileID,'%s\n','I');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,I);
fclose(fileID);

fileID=fopen('rawDataT.txt','w');
fprintf(fileID,'%s\n','T');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,T);
fclose(fileID);

fileID=fopen('rawDataC.txt','w');
fprintf(fileID,'%s\n','C');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,C);
fclose(fileID);

fileID=fopen('rawDataY.txt','w');
fprintf(fileID,'%s\n','Y');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,Y);
fclose(fileID);

fileID=fopen('rawDataL.txt','w');
fprintf(fileID,'%s\n','L');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,L);
fclose(fileID);

fileID=fopen('rawDataF.txt','w');
fprintf(fileID,'%s\n','F');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,F);
fclose(fileID);

fileID=fopen('rawDataQ.txt','w');
fprintf(fileID,'%s\n','Q');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,Q);
fclose(fileID);

fileID=fopen('rawDataH.txt','w');
fprintf(fileID,'%s\n','H');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,H);
fclose(fileID);

fileID=fopen('rawDataP.txt','w');
fprintf(fileID,'%s\n','P');
formatSpec = '%1.4f\n';
fprintf(fileID,formatSpec,P);
fclose(fileID);