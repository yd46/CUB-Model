%% in one species for all the 18 amino acids before replacement

for i=1:18

xb{i}= MidFq1{1,i}{:,1};
yb{i}= MidFq1{1,i}{:,2};

end
