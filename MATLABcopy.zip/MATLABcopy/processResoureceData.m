pasteCodon11=getCodonSequence('sah6.csv');
save 'pasteCodon11.mat' pasteCodon11

pasteCodon12=getCodonSequence('saeu.csv');
save 'pasteCodon12.mat' pasteCodon12

pasteCodon13=getCodonSequence('saku.csv');
save 'pasteCodon13.mat' pasteCodon13

pasteCodon14=getCodonSequence('Ag.csv');
save 'pasteCodon14.mat' pasteCodon14

pasteCodon15=getCodonSequence('Yl.csv');
save 'pasteCodon15.mat' pasteCodon15

pasteCodon21=getCodonSequence('sp.csv');
save 'pasteCodon21.mat' pasteCodon21

pasteCodon22=getCodonSequence('so.csv');
save 'pasteCodon22.mat' pasteCodon22

pasteCodon23=getCodonSequence('sj.csv');
save 'pasteCodon23.mat' pasteCodon23

pasteCodon31=getCodonSequence('ac.csv');
save 'pasteCodon31.mat' pasteCodon31

pasteCodon32=getCodonSequence('afl.csv');
save 'pasteCodon32.mat' pasteCodon32

pasteCodon33=getCodonSequence('ans.csv');
save 'pasteCodon33.mat' pasteCodon33

pasteCodon34=getCodonSequence('anr.csv');
save 'pasteCodon34.mat' pasteCodon34

pasteCodon35=getCodonSequence('ao.csv');
save 'pasteCodon35.mat' pasteCodon35

pasteCodon36=getCodonSequence('at.csv');
save 'pasteCodon36.mat' pasteCodon36

pasteCodon37=getCodonSequence('afu.csv');
save 'pasteCodon37.mat' pasteCodon37

pasteCodon41=getCodonSequence('ff.csv');
save 'pasteCodon41.mat' pasteCodon41

pasteCodon42=getCodonSequence('fg.csv');
save 'pasteCodon42.mat' pasteCodon42

pasteCodon43=getCodonSequence('fo.csv');
save 'pasteCodon43.mat' pasteCodon43

pasteCodon44=getCodonSequence('fv.csv');
save 'pasteCodon44.mat' pasteCodon44

pasteCodon45=getCodonSequence('tr.csv');
save 'pasteCodon45.mat' pasteCodon45