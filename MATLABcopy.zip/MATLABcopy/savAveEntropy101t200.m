[AveEntropyf101t200,pf101t200]=EntropyMean3(4,5);

nohup matlab -nodisplay -nojvm < savAveEntropy101t200.m > mydatatest.m

document need to run for saving 101-200 savAveEntropy101t200.m

now document with saved data AveEntropy4f106t200

Partitions of length 100 for 6 synonymous codons: 96560647, running about 3 hours.