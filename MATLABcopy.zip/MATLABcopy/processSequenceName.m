sequenceName11=getSequenceName('sah6.csv');
save 'sequenceName11,mat' sequenceName11

sequenceName12=getSequenceName('saeu.csv');
save 'sequenceName12.mat' sequenceName12

sequenceName13=getSequenceName('saku.csv');
save 'sequenceName13.mat' sequenceName13

sequenceName14=getSequenceName('Ag.csv');
save 'sequenceName14.mat' sequenceName14

sequenceName15=getSequenceName('Yl.csv');
save 'sequenceName15.mat' sequenceName15

sequenceName21=getSequenceName('sp.csv');
save 'sequenceName21.mat' sequenceName21

sequenceName22=getSequenceName('so.csv');
save 'sequenceName22.mat' sequenceName22

sequenceName23=getSequenceName('sj.csv');
save 'sequenceName23.mat' sequenceName23

sequenceName31=getSequenceName('ac.csv');
save 'sequenceName31.mat' sequenceName31

sequenceName32=getSequenceName('afl.csv');
save 'sequenceName32.mat' sequenceName32

sequenceName33=getSequenceName('ans.csv');
save 'sequenceName33.mat' sequenceName33

sequenceName34=getSequenceName('anr.csv');
save 'sequenceName34.mat' sequenceName34

sequenceName35=getSequenceName('ao.csv');
save 'sequenceName35.mat' sequenceName35

sequenceName36=getSequenceName('at.csv');
save 'sequenceName36.mat' sequenceName36

sequenceName37=getSequenceName('afu.csv');
save 'sequenceName37.mat' sequenceName37

sequenceName41=getSequenceName('ff.csv');
save 'sequenceName41.mat' sequenceName41

sequenceName42=getSequenceName('fg.csv');
save 'sequenceName42.mat' sequenceName42

sequenceName43=getSequenceName('fo.csv');
save 'sequenceName43.mat' sequenceName43

sequenceName44=getSequenceName('fv.csv');
save 'sequenceName44.mat' sequenceName44

sequenceName45=getSequenceName('tr.csv');
save 'sequenceName45.mat' sequenceName45