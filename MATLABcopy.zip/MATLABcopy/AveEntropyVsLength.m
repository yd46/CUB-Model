plot(AveEntropy2,'o');
xlabel('sequence length');
ylabel('average entropy');
title('AveEntropy of 2 synonymous codons');

figure
plot(AveEntropy3,'o');
xlabel('sequence length');
ylabel('average entropy');
title('AveEntropy of 3 synonymous codons');

figure
plot(AveEntropy4,'o');
xlabel('sequence length');
ylabel('average entropy');
title('AveEntropy of 4 synonymous codons');

figure
plot(AveEntropy6,'o');
xlabel('sequence length');
ylabel('average entropy');
title('AveEntropy of 6 synonymous codons');

