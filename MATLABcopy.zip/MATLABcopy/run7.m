clear
clc

pasteCodon=getCodonSequence; %% call function getCodonSequence to creat input 

for i=1:length(pasteCodon)

geneNumber(pasteCodon{1,i});

end