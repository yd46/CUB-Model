
for NN=101:200
    samp6(6,NN,1000000)
end