[AveEntropy(101t200),pf(101t200)]=EntropyMean3(4,5);

save 'AveEntropy(101-200).mat' AveEntropy(101t200) pf(101t200)
