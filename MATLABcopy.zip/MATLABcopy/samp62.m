
for NN=201:300
    samp6(6,NN,1000000)
end