setSynonymousCodonTable
%%for 6 synonymous

% [NNr11,NNs11,NNl11] = getSequenceLength(pasteCodon11);
% save '6sequenceLength11.mat' NNr11 NNs11 NNl11;
% 
% [NNr12,NNs12,NNl12] = getSequenceLength(pasteCodon12);
% save '6sequenceLength12.mat' NNr12 NNs12 NNl12;
% 
% [NNr13,NNs13,NNl13] = getSequenceLength(pasteCodon13);
% save '6sequenceLength13.mat' NNr13 NNs13 NNl13;
% 
% [NNr14,NNs14,NNl14] = getSequenceLength(pasteCodon14);
% save '6sequenceLength14.mat' NNr14 NNs14 NNl14;
% 
% [NNr15,NNs15,NNl15] = getSequenceLength(pasteCodon15);
% save '6sequenceLength15.mat' NNr15 NNs15 NNl15;
% 
% [NNr21,NNs21,NNl21] = getSequenceLength(pasteCodon21);
% save '6sequenceLength21.mat' NNr21 NNs21 NNl21;
% 
% [NNr22,NNs22,NNl22] = getSequenceLength(pasteCodon22);
% save '6sequenceLength22.mat' NNr22 NNs22 NNl22;
% 
% [NNr23,NNs23,NNl23] = getSequenceLength(pasteCodon23);
% save '6sequenceLength23.mat' NNr23 NNs23 NNl23;
% 
% [NNr31,NNs31,NNl31] = getSequenceLength(pasteCodon31);
% save '6sequenceLength31.mat' NNr31 NNs31 NNl31;
% 
% [NNr32,NNs32,NNl32] = getSequenceLength(pasteCodon32);
% save '6sequenceLength32.mat' NNr32 NNs32 NNl32;
% 
% [NNr33,NNs33,NNl33] = getSequenceLength(pasteCodon33);
% save '6sequenceLength33.mat' NNr33 NNs33 NNl33;
% 
% [NNr34,NNs34,NNl34] = getSequenceLength(pasteCodon34);
% save '6sequenceLength34.mat' NNr34 NNs34 NNl34;
% 
% [NNr35,NNs35,NNl35] = getSequenceLength(pasteCodon35);
% save '6sequenceLength35.mat' NNr35 NNs35 NNl35;
% 
% [NNr36,NNs36,NNl36] = getSequenceLength(pasteCodon36);
% save '6sequenceLength36.mat' NNr36 NNs36 NNl36;
% 
% [NNr37,NNs37,NNl37] = getSequenceLength(pasteCodon37);
% save '6sequenceLength37.mat' NNr37 NNs37 NNl37;
% 
% [NNr41,NNs41,NNl41] = getSequenceLength(pasteCodon41);
% save '6sequenceLength41.mat' NNr41 NNs41 NNl41;
% 
% [NNr42,NNs42,NNl42] = getSequenceLength(pasteCodon42);
% save '6sequenceLength42.mat' NNr42 NNs42 NNl42;
% 
% [NNr43,NNs43,NNl43] = getSequenceLength(pasteCodon43);
% save '6sequenceLength43.mat' NNr43 NNs43 NNl43;
% 
% [NNr44,NNs44,NNl44] = getSequenceLength(pasteCodon44);
% save '6sequenceLength44.mat' NNr44 NNs44 NNl44;
% 
% [NNr45,NNs45,NNl45] = getSequenceLength(pasteCodon45);
% save '6sequenceLength45.mat' NNr45 NNs45 NNl45;

%%for 3 synonymous
% NNi11 = getSequenceLength(PasteCodon{1});
% save '3sequenceLength11.mat' NNi11;
% NNi12 = getSequenceLength(PasteCodon{2});
% save '3sequenceLength12.mat' NNi12;
% NNi13 = getSequenceLength(PasteCodon{3});
% save '3sequenceLength13.mat' NNi13;
% NNi14 = getSequenceLength(PasteCodon{4});
% save '3sequenceLength14.mat' NNi14;
% NNi15 = getSequenceLength(PasteCodon{5});
% save '3sequenceLength15.mat' NNi15;
% NNi21 = getSequenceLength(PasteCodon{6});
% save '3sequenceLength21.mat' NNi21;
% NNi22 = getSequenceLength(PasteCodon{7});
% save '3sequenceLength22.mat' NNi22;
% NNi23 = getSequenceLength(PasteCodon{8});
% save '3sequenceLength23.mat' NNi23;
% NNi31 = getSequenceLength(PasteCodon{9});
% save '3sequenceLength31.mat' NNi31;
% NNi32 = getSequenceLength(PasteCodon{10});
% save '3sequenceLength32.mat' NNi32;
% NNi33 = getSequenceLength(PasteCodon{11});
% save '3sequenceLength33.mat' NNi33;
% NNi34 = getSequenceLength(PasteCodon{12});
% save '3sequenceLength34.mat' NNi34;
% NNi35 = getSequenceLength(PasteCodon{13});
% save '3sequenceLength35.mat' NNi35;
% NNi36 = getSequenceLength(PasteCodon{14});
% save '3sequenceLength36.mat' NNi36;
% NNi37 = getSequenceLength(PasteCodon{15});
% save '3sequenceLength37.mat' NNi37;
% NNi41 = getSequenceLength(PasteCodon{16});
% save '3sequenceLength41.mat' NNi41;
% NNi42 = getSequenceLength(PasteCodon{17});
% save '3sequenceLength42.mat' NNi42;
% NNi43 = getSequenceLength(PasteCodon{18});
% save '3sequenceLength43.mat' NNi43;
% NNi44 = getSequenceLength(PasteCodon{19});
% save '3sequenceLength44.mat' NNi44;
% NNi45 = getSequenceLength(PasteCodon{20});
% save '3sequenceLength45.mat' NNi45;

% for 4 synonymous

% pasteCodon=PasteCodon{1};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength11.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{2};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength12.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{3};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength13.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{4};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength14.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{5};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength15.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{6};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength21.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{7};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength22.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{8};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength23.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{9};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength31.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{10};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength32.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{11};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength33.mat' NNg NNe NNv NNa NNt NNp
% 
% 
% pasteCodon=PasteCodon{12};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength34.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{13};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength35.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{14};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength36.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{15};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength37.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{16};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength41.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{17};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength42.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{18};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength43.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{19};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength44.mat' NNg NNe NNv NNa NNt NNp
% 
% pasteCodon=PasteCodon{20};
% 
% [NNg,NNe,NNv,NNa,NNt,NNp]= getSequenceLength(pasteCodon);
% 
% save '4sequenceLength45.mat' NNg NNe NNv NNa NNt NNp

%% 2 syno
% load pasteCodon11.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon11);
save '2sequenceLength11.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon12.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon12);
save '2sequenceLength12.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon13.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon13);
save '2sequenceLength13.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon14.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon14);
save '2sequenceLength14.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon15.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon15);
save '2sequenceLength15.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon21.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon21);
save '2sequenceLength21.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon22.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon22);
save '2sequenceLength22.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon23.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon23);
save '2sequenceLength23.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon31.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon31);
save '2sequenceLength31.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon32.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon32);
save '2sequenceLength32.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon33.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon33);
save '2sequenceLength33.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon34.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon34);
save '2sequenceLength34.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon35.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon35);
save '2sequenceLength35.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon36.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon36);
save '2sequenceLength36.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon37.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon37);
save '2sequenceLength37.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon41.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon41);
save '2sequenceLength41.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon42.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon42);
save '2sequenceLength42.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon43.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon43);
save '2sequenceLength43.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon44.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon44);
save '2sequenceLength44.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh

load pasteCodon45.mat
[NNd,NNe,NNk,NNn,NNc,NNy,NNf,NNq,NNh]= getSequenceLength(pasteCodon45);
save '2sequenceLength45.mat' NNd NNe NNk NNn NNc NNy NNf NNq NNh



