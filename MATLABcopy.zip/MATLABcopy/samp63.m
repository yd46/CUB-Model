
for NN=301:400
    samp6(6,NN,1000000)
end