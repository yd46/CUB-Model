l=200:100:2000;
ss=arrayfun(@entropy3,l);
plot(l,ss);