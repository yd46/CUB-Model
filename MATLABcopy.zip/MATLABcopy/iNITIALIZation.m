setSynonymousCodonTable

% global cfG cfGT ctG cfD cfDT ctD cfE cfET ctE cfV cfVT ctV cfA cfAT ctA cfR cfRT ctR cfS cfST ctS cfK cfKT ctK cfN cfNT ctN cfI cfIT ctI cfT cfTT ctT cfC cfCT ctC cfY cfYT ctY cfL cfLT ctL cfF cfFT ctF cfQ cfQT ctQ cfH cfHT ctH cfP cfPT ctP;

global cfG cfGT ctG cfP cfPT ctP
% FileName={'pasteCodon11.mat','pasteCodon12.mat','pasteCodon13.mat','pasteCodon14.mat','pasteCodon15.mat',...
%     'pasteCodon21.mat','pasteCodon22.mat','pasteCodon23.mat',...
%     'pasteCodon31.mat','pasteCodon32.mat','pasteCodon33.mat','pasteCodon34.mat','pasteCodon35.mat','pasteCodon36.mat','pasteCodon37.mat',...
%     'pasteCodon41.mat','pasteCodon42.mat','pasteCodon43.mat','pasteCodon44.mat','pasteCodon45.mat'};
% 
% PasteCodon=cell(1,20);
% 
% for r=1:20 
% 
% m=matfile(FileName{r});
% 
% v=who(m);
% 
% vn=v{1};
%     
% PasteCodon{r}=m.(vn);
% 
% end
% 
% SpeciesName={'sah6','saeu','saku','Ag','Yl','sp','so','sj','ac','afl','ans','anr','ao','at','afu','ff','fg','fo','fv','tr'};
% 
% % load('AveEntropy2f.mat');
% % load('AveEntropy3f.mat');
% % load('AveEntropy4f.mat');
% % load('AveEntropy6.mat');
